package com.example.flutter_mi_primera_app_n0_a_n1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
